# Market Basket Analysis using Data Mining

Data Mining Lab (CSE-404), Feni University — Lab Report No. 01 (Labs 1–12).

A complete data-mining workflow on grocery transactions: preprocessing, exploratory analysis, association rules
(Apriori and FP-Growth), classification, customer clustering, outlier detection and an interactive product recommender.

## Contents

| File | Description |
|---|---|
| `Market_Basket_Analysis_Lab_Codes.ipynb` | All code for Labs 1–12, one section per lab, plus the interactive dashboard |
| `data/market_basket_transactions.csv` | Synthetic grocery transactions (6,000 baskets, 37 products) |
| `requirements.txt` | Python libraries (pre-installed on Google Colab) |

## Labs

| Lab | Topic | Lab | Topic |
|---|---|---|---|
| 1 | Python and Pandas basics | 7 | Naive Bayes classification |
| 2 | Data preprocessing | 8 | SVM classification |
| 3 | Visualization and EDA | 9 | K-Means customer segmentation (RFM) |
| 4 | Apriori | 10 | Hierarchical clustering and DBSCAN |
| 5 | FP-Growth | 11 | Outlier detection and Random Forest |
| 6 | Decision Tree classification | 12 | End-to-end recommender and dashboard |

## How to run

**Google Colab:** open <https://colab.research.google.com>, choose *File → Upload notebook*, upload the `.ipynb`,
then upload `market_basket_transactions.csv` into a folder named `data` (or let Step 0 generate a similar dataset), and press *Runtime → Run all*.

**Locally:**
```bash
pip install -r requirements.txt
jupyter notebook Market_Basket_Analysis_Lab_Codes.ipynb
```

## Dataset

The data is **synthetic**: generated with a fixed random seed to mimic store receipts
(columns `TransactionID, CustomerID, Date, Item, Quantity, UnitPrice`). It deliberately contains a few missing customer IDs,
duplicate rows and zero quantities so the preprocessing lab has something to clean.
To use real data (for example the Kaggle *Groceries* or *Instacart* datasets), save it with the same columns as
`data/market_basket_transactions.csv`.

## Note

Educational project. Results come from synthetic data and should not be used for business decisions.
